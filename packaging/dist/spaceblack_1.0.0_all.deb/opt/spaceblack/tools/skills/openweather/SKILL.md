Located within skill folders, these files contain metadata and instructions defining a specific, portable capability for the agent.

# OpenWeather Skill

## Capability
Fetches real-time weather data for any city.

## Usage
- `get_current_weather(city)`
