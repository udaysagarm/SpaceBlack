Located within skill folders, these files contain metadata and instructions defining a specific, portable capability for the agent.

# Telegram Skill

## Capability
Allows the user to interact with the agent via Telegram.

## Files
- `bot.py`: Main bot logic.
