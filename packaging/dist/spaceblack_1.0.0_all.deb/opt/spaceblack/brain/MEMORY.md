The main long-term, curated memory file. The agent updates this file with stable facts, user preferences, and important decisions that should persist across sessions.

# Long-Term Memory

## Key Facts
- [Auto-generated from daily logs]

## User Preferences
- [Auto-generated from USER.md updates]
