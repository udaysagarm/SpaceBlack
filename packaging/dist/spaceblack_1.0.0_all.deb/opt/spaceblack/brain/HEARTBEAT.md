Used for scheduling planned tasks, reminders, and cron jobs.

# HEARTBEAT INSTRUCTIONS

- **Frequency**: Every 600 seconds.
- **Tasks**:
    1. Check for system alerts.
    2. Review recent memory logs.
    3. Update `heartbeat-state.json` with timestamp.
